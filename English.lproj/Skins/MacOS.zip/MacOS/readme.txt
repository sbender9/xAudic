MacOS skin for Winamp
=======================================
Version 1.0

This MacOS-like skin is made only from
screenshots of MacOS desktops. Therefore
it may be a little "incorrect". If anyone
can give me some more screenshots (of the
MacOS GUI) please send me a mail.

 - Tobias of DiSTORTiON (toe_dst@iname.com)
